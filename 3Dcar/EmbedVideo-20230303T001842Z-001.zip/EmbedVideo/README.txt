Instructions for making your video project reflection are as follows:
1. Change the "Title of the document" "Project Reflection" to be specific to your project. 
2. Add a few sentences about the project in the section between the <p> tags. This will add context for viewers of your video. 
3. Replace your video with the one titled:"ReplaceThisVideoWithYours.mp4" and make sure it is in the EmbedVideo folder